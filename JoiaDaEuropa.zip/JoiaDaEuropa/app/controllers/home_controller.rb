class HomeController < ApplicationController

	def index


	end

	def quem


	end


end