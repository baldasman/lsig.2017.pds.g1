class StaticPagesController < ApplicationController
  def home
  end

  def quemsomos
  end

  def missao
  end

  def contactos
  end
end
